> Aurora 官方仓库，其他渠道均是盗版发布。

# Welcome
欢迎使用 Aurora 主题，获取更新，请关注 [Fox Design](https://t.me/foxdesignteam) .

# 使用教程
使用教程:  [Aurora for v2board](https://kun-pehs-organization.gitbook.io/aurora-for-v2board/)
